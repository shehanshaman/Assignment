1) compile HashTableImp.java file.
2) There is two way to run the pro gramme
	
	* 	java HashTableImp 
		-there has default values for 
			file name 		= sample-text1.txt
			hash function 	= 2 
			
	* 	java HashTableImp (file name) (hash function number)
			-hash function number = 1 or 2